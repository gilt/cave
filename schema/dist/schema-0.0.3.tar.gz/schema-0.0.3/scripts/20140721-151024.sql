--------------------
-- Organizations ---
--------------------
create table organizations (
     id                   bigserial not null,
     name                 text not null,
     email                text not null,
     notification_url     text not null,
     primary key (id)
);

select schema_evolution_manager.create_basic_audit_data('public', 'organizations');
create unique index organizations_name_not_deleted_un_idx
    on organizations (name) where deleted_at is null;

--------------------
--     Teams     ---
--------------------
create table teams (
     id                   bigserial not null,
     organization_id      bigint not null,
     name                 text not null,
     primary key (id)
);

select schema_evolution_manager.create_basic_audit_data('public', 'teams');
create unique index teams_name_not_deleted_un_idx
    on teams (name) where deleted_at is null;

--------------------
--    Tokens     ---
--------------------
create table tokens (
     id                   bigserial not null,
     organization_id      bigint not null,
     team_id              bigint,
     description          text not null,
     value                text not null,
     primary key (id)
);

select schema_evolution_manager.create_basic_audit_data('public', 'tokens');
create unique index tokens_id_not_deleted_un_idx
    on tokens (id) where deleted_at is null;
create index tokens_by_organization_not_deleted_idx
    on tokens (organization_id) where team_id is null and deleted_at is null;
create index tokens_by_team_not_deleted_idx
    on tokens (team_id) where deleted_at is null;

--------------------
--    Alerts     ---
--------------------
create table alerts (
     id                   bigserial not null,
     organization_id      bigint not null,
     team_id              bigint,
     description          text not null,
     status               bool,
     condition            text not null,
     period               text not null,
     primary key (id)
);

select schema_evolution_manager.create_basic_audit_data('public', 'alerts');
create unique index alerts_id_not_deleted_un_idx
    on alerts (id) where deleted_at is null;
create index alerts_by_organization_not_deleted_idx
    on alerts (organization_id) where team_id is null and deleted_at is null;
create index alerts_by_team_not_deleted_idx
    on alerts (team_id) where deleted_at is null;


--------------------
--    Queries    ---
--------------------
create table queries (
     id                   bigserial not null,
     name                 text not null check (lower(trim(name)) = name),
     metric               json not null,
     primary key (id)
);

comment on column queries.name is '
  This is the generated name for a query. We look at the metric
  definition and create a name that is valid for influx db. The name
  will contain the original metric name, all tags, and any aggregator
  function / period.

  An example name would be response_time.app:product_service.p99.5m
';

select schema_evolution_manager.create_basic_audit_data('public', 'queries');
create unique index queries_id on queries (id);
create unique index queries_name_not_deleted_un_idx
    on queries(name) where deleted_at is null;

--------------------
-- Alert Queries  --
--------------------
create table alert_queries (
     id                   bigserial not null,
     alert_id             bigint not null,
     query_id             bigint not null,
     primary key (id)
);

select schema_evolution_manager.create_basic_audit_data('public', 'alert_queries');
create index alert_queries_alert_id on alert_queries (alert_id);
create index alert_queries_query_id on alert_queries (query_id);
create unique index alert_queries_alert_id_query_id_not_deleted_un_idx
    on alert_queries(alert_id, query_id) where deleted_at is null;

--------------------
-- Relationships  --
--------------------
alter table teams
  add constraint team_organization_fk
  foreign key (organization_id) references organizations (id);

alter table tokens
  add constraint token_team_fk
  foreign key (team_id) references teams (id);

alter table tokens
  add constraint token_organization_fk
  foreign key (organization_id) references organizations (id);

alter table alerts
  add constraint alert_organization_fk
  foreign key (organization_id) references organizations (id);

alter table alerts
  add constraint alert_team_fk
  foreign key (team_id) references teams (id);

alter table alert_queries
  add constraint alertquery_alert_fk
  foreign key (alert_id) references alerts (id);

alter table alert_queries
  add constraint alertquery_query_fk
  foreign key (query_id) references queries (id);